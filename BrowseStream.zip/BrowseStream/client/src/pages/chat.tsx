import { useState, useEffect } from "react";
import { Sidebar } from "@/components/chat/sidebar";
import { ChatInterface } from "@/components/chat/chat-interface";
import { useChat } from "@/hooks/use-chat";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Simple user management for demo - in production, use proper auth
const getOrCreateUser = async () => {
  const storedUser = localStorage.getItem("ai-chat-user");
  
  if (storedUser) {
    return JSON.parse(storedUser);
  }

  // Create a new user
  const userData = {
    username: `user_${Date.now()}`,
    email: `user_${Date.now()}@example.com`,
  };

  try {
    const response = await apiRequest("POST", "/api/users", userData);
    const user = await response.json();
    localStorage.setItem("ai-chat-user", JSON.stringify(user));
    return user;
  } catch (error) {
    console.error("Failed to create user:", error);
    throw error;
  }
};

export default function ChatPage() {
  const [userId, setUserId] = useState<string>("");
  const [isInitializing, setIsInitializing] = useState(true);
  const { toast } = useToast();

  const {
    conversations,
    currentConversationId,
    isLoadingConversations,
    createConversation,
    selectConversation,
    isCreatingConversation,
  } = useChat({ userId });

  // Initialize user on mount
  useEffect(() => {
    const initUser = async () => {
      try {
        const user = await getOrCreateUser();
        setUserId(user.id);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to initialize user session",
          variant: "destructive",
        });
      } finally {
        setIsInitializing(false);
      }
    };

    initUser();
  }, [toast]);

  const handleNewChat = () => {
    if (isCreatingConversation) return;
    
    const title = `Chat ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    createConversation(title);
  };

  const handleExportConversation = async (conversationId: string) => {
    try {
      const response = await fetch(`/api/conversations/${conversationId}/export`);
      if (response.ok) {
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `conversation-${conversationId}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast({
          title: "Success",
          description: "Conversation exported successfully",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export conversation",
        variant: "destructive",
      });
    }
  };

  if (isInitializing) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Initializing AI Assistant...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar
        conversations={conversations}
        currentConversationId={currentConversationId}
        onNewChat={handleNewChat}
        onSelectConversation={selectConversation}
        onExportConversation={handleExportConversation}
        isLoading={isLoadingConversations}
      />
      <ChatInterface
        userId={userId}
        conversationId={currentConversationId}
      />
    </div>
  );
}
