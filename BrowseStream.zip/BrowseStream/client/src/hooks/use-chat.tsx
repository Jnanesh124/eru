import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Conversation, type Message, type User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface ChatHookParams {
  userId: string;
}

export function useChat({ userId }: ChatHookParams) {
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Get user conversations
  const {
    data: conversations = [],
    isLoading: isLoadingConversations,
    refetch: refetchConversations
  } = useQuery<Conversation[]>({
    queryKey: ["/api/users", userId, "conversations"],
    enabled: !!userId,
  });

  // Get current conversation messages
  const {
    data: messages = [],
    isLoading: isLoadingMessages,
    refetch: refetchMessages
  } = useQuery<Message[]>({
    queryKey: ["/api/conversations", currentConversationId, "messages"],
    enabled: !!currentConversationId,
  });

  // Create new conversation
  const createConversationMutation = useMutation({
    mutationFn: async (title: string) => {
      const response = await apiRequest("POST", "/api/conversations", {
        userId,
        title,
      });
      return response.json();
    },
    onSuccess: (newConversation) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "conversations"] });
      setCurrentConversationId(newConversation.id);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create new conversation",
        variant: "destructive",
      });
    },
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ content, metadata }: { content: string; metadata?: any }) => {
      if (!currentConversationId) throw new Error("No conversation selected");
      
      const response = await apiRequest("POST", `/api/conversations/${currentConversationId}/messages`, {
        content,
        metadata,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/conversations", currentConversationId, "messages"] 
      });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/users", userId, "conversations"] 
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
      console.error("Send message error:", error);
    },
  });

  // Initialize WebSocket connection
  useEffect(() => {
    if (!currentConversationId) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("WebSocket connected");
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'stream-start':
          setIsStreaming(true);
          setIsTyping(true);
          break;
        case 'stream-chunk':
          // Handle streaming chunks - you could update UI in real-time here
          break;
        case 'stream-end':
          setIsStreaming(false);
          setIsTyping(false);
          queryClient.invalidateQueries({ 
            queryKey: ["/api/conversations", currentConversationId, "messages"] 
          });
          queryClient.invalidateQueries({ 
            queryKey: ["/api/users", userId, "conversations"] 
          });
          break;
        case 'error':
          setIsStreaming(false);
          setIsTyping(false);
          toast({
            title: "Error",
            description: data.payload.message || "An error occurred",
            variant: "destructive",
          });
          break;
      }
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
      setIsStreaming(false);
      setIsTyping(false);
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      setIsStreaming(false);
      setIsTyping(false);
    };

    return () => {
      ws.close();
    };
  }, [currentConversationId, userId, queryClient, toast]);

  // Send message via WebSocket for streaming
  const sendMessageStream = useCallback((content: string, metadata?: any) => {
    if (!wsRef.current || !currentConversationId) return;
    
    wsRef.current.send(JSON.stringify({
      type: 'stream-message',
      payload: {
        conversationId: currentConversationId,
        content,
        metadata,
      }
    }));
  }, [currentConversationId]);

  // Create new conversation
  const createConversation = useCallback((title: string = "New Chat") => {
    createConversationMutation.mutate(title);
  }, [createConversationMutation]);

  // Send message (regular)
  const sendMessage = useCallback((content: string, metadata?: any) => {
    sendMessageMutation.mutate({ content, metadata });
  }, [sendMessageMutation]);

  // Select conversation
  const selectConversation = useCallback((conversationId: string) => {
    setCurrentConversationId(conversationId);
  }, []);

  return {
    // State
    conversations,
    messages,
    currentConversationId,
    isTyping,
    isStreaming,
    isLoadingConversations,
    isLoadingMessages,
    
    // Actions
    createConversation,
    selectConversation,
    sendMessage,
    sendMessageStream,
    refetchConversations,
    refetchMessages,
    
    // Loading states
    isCreatingConversation: createConversationMutation.isPending,
    isSendingMessage: sendMessageMutation.isPending,
  };
}
