import hljs from 'highlight.js';

// Configure common languages
const commonLanguages = [
  'javascript', 'typescript', 'python', 'java', 'cpp', 'c', 'csharp', 'php', 
  'ruby', 'go', 'rust', 'swift', 'kotlin', 'scala', 'bash', 'sql', 'json', 
  'xml', 'html', 'yaml', 'css', 'markdown', 'dockerfile', 'nginx', 'apache'
];

export function highlightCode(code: string, language?: string): string {
  if (language && hljs.getLanguage(language)) {
    try {
      return hljs.highlight(code, { language }).value;
    } catch (error) {
      console.warn(`Error highlighting code with language ${language}:`, error);
    }
  }
  
  // Auto-detect language if not specified or if specified language failed
  try {
    return hljs.highlightAuto(code).value;
  } catch (error) {
    console.warn('Error auto-detecting language:', error);
    return code;
  }
}

export function detectLanguage(code: string): string {
  try {
    const result = hljs.highlightAuto(code);
    return result.language || 'text';
  } catch (error) {
    console.warn('Error detecting language:', error);
    return 'text';
  }
}

export const supportedLanguages = [
  'javascript', 'typescript', 'python', 'java', 'cpp', 'c', 'csharp',
  'php', 'ruby', 'go', 'rust', 'swift', 'kotlin', 'scala', 'bash',
  'sql', 'json', 'xml', 'html', 'yaml', 'css', 'markdown', 'dockerfile',
  'nginx', 'apache', 'perl', 'lua', 'haskell', 'erlang', 'elixir', 'clojure',
  'fsharp', 'assembly', 'fortran', 'cobol', 'ada', 'prolog', 'lisp', 'scheme',
  'matlab', 'r', 'julia', 'dart', 'groovy', 'powershell', 'vbnet', 'delphi',
  'pascal', 'tcl', 'awk', 'sed', 'vim', 'tex', 'latex', 'diff', 'patch',
  'ini', 'properties', 'toml', 'gradle', 'makefile', 'cmake', 'dockerfile',
  'graphql', 'solidity', 'vyper', 'brainfuck', 'lolcode', 'whitespace'
];

export default hljs;
