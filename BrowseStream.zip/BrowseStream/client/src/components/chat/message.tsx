import { type Message } from "@shared/schema";
import { CodeBlock } from "./code-block";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

interface MessageProps {
  message: Message;
  className?: string;
}

export function ChatMessage({ message, className }: MessageProps) {
  const isUser = message.role === "user";
  const timeAgo = message.createdAt ? formatDistanceToNow(new Date(message.createdAt), { addSuffix: true }) : "";

  // Parse content for code blocks
  const parseContent = (content: string) => {
    const codeBlockRegex = /```(\w+)?\n?([\s\S]*?)```/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      // Add text before code block
      if (match.index > lastIndex) {
        parts.push({
          type: 'text',
          content: content.slice(lastIndex, match.index).trim(),
        });
      }

      // Add code block
      parts.push({
        type: 'code',
        language: match[1] || 'text',
        content: match[2].trim(),
      });

      lastIndex = match.index + match[0].length;
    }

    // Add remaining text
    if (lastIndex < content.length) {
      parts.push({
        type: 'text',
        content: content.slice(lastIndex).trim(),
      });
    }

    return parts.length > 0 ? parts : [{ type: 'text', content }];
  };

  const contentParts = parseContent(message.content);

  return (
    <div className={cn("message-bubble", className)}>
      <div className={cn(
        "flex items-start gap-3",
        isUser ? "justify-end" : "justify-start"
      )}>
        {!isUser && (
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-primary-foreground text-sm">🤖</span>
          </div>
        )}
        
        <div className={cn("flex-1", isUser ? "text-right" : "text-left")}>
          <div className={cn(
            "rounded-2xl p-4 max-w-3xl",
            isUser 
              ? "bg-primary text-primary-foreground inline-block" 
              : "bg-muted text-muted-foreground"
          )}>
            <div className="space-y-3">
              {contentParts.map((part, index) => (
                <div key={index}>
                  {part.type === 'text' ? (
                    <p className={cn(
                      "whitespace-pre-wrap",
                      isUser ? "text-primary-foreground" : "text-foreground"
                    )}>
                      {part.content}
                    </p>
                  ) : (
                    <CodeBlock 
                      code={part.content} 
                      language={part.language} 
                      className="mt-3"
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className={cn(
            "text-xs text-muted-foreground mt-2",
            isUser ? "text-right" : "text-left"
          )}>
            {isUser ? "You" : "AI Assistant"} • {timeAgo}
          </div>
        </div>

        {isUser && (
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-muted-foreground text-sm">👤</span>
          </div>
        )}
      </div>
    </div>
  );
}
