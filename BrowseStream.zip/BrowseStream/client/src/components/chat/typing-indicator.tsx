export function TypingIndicator() {
  return (
    <div className="message-bubble">
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
          <span className="text-primary-foreground text-sm">🤖</span>
        </div>
        <div className="flex-1">
          <div className="bg-muted rounded-2xl p-4 w-16">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-muted-foreground rounded-full typing-dot"></div>
              <div className="w-2 h-2 bg-muted-foreground rounded-full typing-dot"></div>
              <div className="w-2 h-2 bg-muted-foreground rounded-full typing-dot"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
