import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "@/hooks/use-theme";
import { type Conversation } from "@shared/schema";
import { Plus, Moon, Sun, User, Download } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onNewChat: () => void;
  onSelectConversation: (id: string) => void;
  onExportConversation?: (id: string) => void;
  isLoading?: boolean;
}

export function Sidebar({
  conversations,
  currentConversationId,
  onNewChat,
  onSelectConversation,
  onExportConversation,
  isLoading = false,
}: SidebarProps) {
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-sidebar-foreground">AI Assistant</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            className="p-2 hover:bg-sidebar-accent text-sidebar-foreground hover:text-sidebar-accent-foreground"
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>

      {/* New Chat Button */}
      <div className="p-4">
        <Button
          onClick={onNewChat}
          className="w-full bg-sidebar-primary hover:bg-sidebar-primary/90 text-sidebar-primary-foreground"
        >
          <Plus className="h-4 w-4 mr-2" />
          New Chat
        </Button>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-hidden">
        <div className="px-4 pb-2">
          <h3 className="text-sm font-medium text-sidebar-foreground/70">
            Recent Conversations
          </h3>
        </div>
        
        <ScrollArea className="flex-1 px-4 custom-scrollbar">
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-12 bg-sidebar-accent/50 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : conversations.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-sm text-sidebar-foreground/50">No conversations yet</p>
              <p className="text-xs text-sidebar-foreground/40 mt-1">
                Start a new chat to begin
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {conversations.map((conversation) => (
                <div key={conversation.id} className="group relative">
                  <Button
                    variant="ghost"
                    onClick={() => onSelectConversation(conversation.id)}
                    className={cn(
                      "w-full text-left p-3 h-auto hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors",
                      currentConversationId === conversation.id &&
                        "bg-sidebar-accent text-sidebar-accent-foreground"
                    )}
                  >
                    <div className="truncate pr-6">
                      <div className="font-medium truncate text-sm">
                        {conversation.title}
                      </div>
                      <div className="text-xs text-sidebar-foreground/60 mt-1">
                        {conversation.updatedAt &&
                          formatDistanceToNow(new Date(conversation.updatedAt), { addSuffix: true })}
                      </div>
                    </div>
                  </Button>
                  
                  {onExportConversation && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onExportConversation(conversation.id);
                      }}
                      className="absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity p-1 h-6 w-6"
                    >
                      <Download className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </div>

      <Separator />

      {/* User Profile */}
      <div className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-sidebar-primary rounded-full flex items-center justify-center">
            <User className="h-4 w-4 text-sidebar-primary-foreground" />
          </div>
          <div className="flex-1">
            <div className="text-sm font-medium text-sidebar-foreground">Developer</div>
            <div className="text-xs text-sidebar-foreground/60">Ready to code</div>
          </div>
        </div>
      </div>
    </div>
  );
}
