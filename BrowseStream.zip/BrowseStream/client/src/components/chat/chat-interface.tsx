import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChatMessage } from "./message";
import { TypingIndicator } from "./typing-indicator";
import { useChat } from "@/hooks/use-chat";
import { Send, Paperclip, Search, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface ChatInterfaceProps {
  userId: string;
  conversationId: string | null;
}

export function ChatInterface({ userId, conversationId }: ChatInterfaceProps) {
  const [input, setInput] = useState("");
  const [isComposing, setIsComposing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const {
    messages,
    isTyping,
    isStreaming,
    isLoadingMessages,
    sendMessage,
    sendMessageStream,
    isSendingMessage,
  } = useChat({ userId });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [input]);

  const handleSend = async () => {
    if (!input.trim() || !conversationId || isSendingMessage) return;

    const messageContent = input.trim();
    setInput("");
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    try {
      // Use streaming for better user experience
      sendMessageStream(messageContent);
    } catch (error) {
      console.error("Failed to send message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey && !isComposing) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleExport = async () => {
    if (!conversationId) return;
    
    try {
      const response = await fetch(`/api/conversations/${conversationId}/export`);
      if (response.ok) {
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `conversation-${conversationId}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast({
          title: "Success",
          description: "Conversation exported successfully",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export conversation",
        variant: "destructive",
      });
    }
  };

  if (!conversationId) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">💬</span>
          </div>
          <h3 className="text-lg font-semibold mb-2">Welcome to AI Assistant</h3>
          <p className="text-muted-foreground max-w-md">
            Start a new conversation to begin chatting with your AI coding assistant.
            I can help with programming questions, code reviews, debugging, and more!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Chat Header */}
      <div className="p-4 border-b border-border bg-background">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">AI Code Assistant</h2>
            <p className="text-sm text-muted-foreground">
              Ready to help with your programming questions
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExport}
              className="p-2"
              title="Export Chat"
            >
              <Download className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="p-2"
              title="Search"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages Container */}
      <ScrollArea className="flex-1 p-4 custom-scrollbar">
        <div className="space-y-6 pb-4">
          {isLoadingMessages ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-8 h-8 bg-muted rounded-full animate-pulse" />
                  <div className="flex-1">
                    <div className="h-16 bg-muted rounded-2xl animate-pulse" />
                  </div>
                </div>
              ))}
            </div>
          ) : messages.length === 0 ? (
            <div className="message-bubble">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-primary-foreground text-sm">🤖</span>
                </div>
                <div className="flex-1">
                  <div className="bg-muted rounded-2xl p-4">
                    <p className="text-foreground">
                      Hello! I'm your AI coding assistant. I can help you with programming questions, 
                      code reviews, debugging, and more. I support over 50 programming languages with 
                      syntax highlighting. What would you like to work on today?
                    </p>
                  </div>
                  <div className="text-xs text-muted-foreground mt-2">
                    AI Assistant • Just now
                  </div>
                </div>
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))
          )}
          
          {(isTyping || isStreaming) && <TypingIndicator />}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 border-t border-border bg-background">
        <div className="flex items-end gap-3">
          {/* File Upload */}
          <Button
            variant="ghost"
            size="sm"
            className="p-3 shrink-0"
            title="Upload File"
          >
            <Paperclip className="h-4 w-4" />
          </Button>

          {/* Message Input */}
          <div className="flex-1 relative">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              onCompositionStart={() => setIsComposing(true)}
              onCompositionEnd={() => setIsComposing(false)}
              placeholder="Ask me anything about programming..."
              className={cn(
                "min-h-[44px] max-h-32 resize-none pr-12",
                "focus:ring-2 focus:ring-primary focus:border-transparent"
              )}
              rows={1}
            />

            {/* Send Button */}
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isSendingMessage || isStreaming}
              size="sm"
              className="absolute right-2 bottom-2 p-2 h-8 w-8"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Input Hints */}
        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <span>⌨️</span>
            Press Shift+Enter for new line
          </span>
          <span className="flex items-center gap-1">
            <span>💻</span>
            50+ languages supported
          </span>
          <span className="flex items-center gap-1">
            <span>📁</span>
            Upload code files
          </span>
        </div>
      </div>
    </div>
  );
}
