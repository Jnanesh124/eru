import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertConversationSchema, insertMessageSchema, insertUserSchema } from "@shared/schema";
import { generateChatResponse, generateChatResponseStream, analyzeCode, generateCodeCompletion } from "./services/openai";
import multer, { type Request as MulterRequest } from "multer";

const upload = multer({ storage: multer.memoryStorage() });

interface MulterFile {
  buffer: Buffer;
  originalname: string;
  size: number;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create or get user (simplified auth for demo)
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user exists
      let user = await storage.getUserByEmail(userData.email);
      if (!user) {
        user = await storage.createUser(userData);
      }
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error: (error as Error).message });
    }
  });

  // Get user conversations
  app.get("/api/users/:userId/conversations", async (req, res) => {
    try {
      const conversations = await storage.getConversationsByUserId(req.params.userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  // Create new conversation
  app.post("/api/conversations", async (req, res) => {
    try {
      const conversationData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      res.status(400).json({ message: "Invalid conversation data", error: (error as Error).message });
    }
  });

  // Get conversation messages
  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const messages = await storage.getMessagesByConversationId(req.params.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send message and get AI response
  app.post("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { content, metadata } = req.body;
      const conversationId = req.params.id;

      // Save user message
      const userMessage = await storage.createMessage({
        conversationId,
        role: "user",
        content,
        metadata,
      });

      // Get conversation history for context
      const messages = await storage.getMessagesByConversationId(conversationId);
      const chatHistory = messages.map(msg => ({
        role: msg.role as "user" | "assistant",
        content: msg.content,
      }));

      // Generate AI response
      const aiResponse = await generateChatResponse(chatHistory);

      // Save AI message
      const aiMessage = await storage.createMessage({
        conversationId,
        role: "assistant",
        content: aiResponse,
      });

      // Update conversation timestamp
      await storage.updateConversation(conversationId, {
        updatedAt: new Date(),
      });

      res.json({ userMessage, aiMessage });
    } catch (error) {
      console.error("Message error:", error);
      res.status(500).json({ message: "Failed to process message", error: (error as Error).message });
    }
  });

  // Code analysis endpoint
  app.post("/api/analyze-code", async (req, res) => {
    try {
      const { code, language } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ message: "Code and language are required" });
      }

      const analysis = await analyzeCode(code, language);
      res.json(analysis);
    } catch (error) {
      console.error("Code analysis error:", error);
      res.status(500).json({ message: "Failed to analyze code", error: (error as Error).message });
    }
  });

  // Code completion endpoint
  app.post("/api/complete-code", async (req, res) => {
    try {
      const { prompt, language } = req.body;
      
      if (!prompt || !language) {
        return res.status(400).json({ message: "Prompt and language are required" });
      }

      const completion = await generateCodeCompletion(prompt, language);
      res.json({ completion });
    } catch (error) {
      console.error("Code completion error:", error);
      res.status(500).json({ message: "Failed to generate code completion", error: (error as Error).message });
    }
  });

  // File upload for code analysis
  app.post("/api/upload-file", upload.single("file"), async (req: any, res) => {
    try {
      const file = req.file as MulterFile | undefined;
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const content = file.buffer.toString('utf-8');
      const filename = file.originalname;
      const language = getLanguageFromFilename(filename);

      res.json({
        content,
        filename,
        language,
        size: file.size,
      });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ message: "Failed to process file upload" });
    }
  });

  // Export conversation
  app.get("/api/conversations/:id/export", async (req, res) => {
    try {
      const conversation = await storage.getConversation(req.params.id);
      const messages = await storage.getMessagesByConversationId(req.params.id);

      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      const exportData = {
        conversation,
        messages,
        exportedAt: new Date().toISOString(),
      };

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="conversation-${conversation.id}.json"`);
      res.json(exportData);
    } catch (error) {
      console.error("Export error:", error);
      res.status(500).json({ message: "Failed to export conversation" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time streaming on a specific path to avoid Vite conflicts
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: '/ws',
    perMessageDeflate: false
  });

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');

    ws.on('message', async (data) => {
      try {
        const message = data.toString();
        if (!message || message.length === 0) return;
        
        const { type, payload } = JSON.parse(message);

        if (type === 'stream-message') {
          const { conversationId, content } = payload;

          // Save user message
          await storage.createMessage({
            conversationId,
            role: "user",
            content,
          });

          // Get conversation history
          const messages = await storage.getMessagesByConversationId(conversationId);
          const chatHistory = messages.map(msg => ({
            role: msg.role as "user" | "assistant",
            content: msg.content,
          }));

          // Stream AI response
          const stream = await generateChatResponseStream(chatHistory);
          let fullResponse = "";

          if (ws.readyState === ws.OPEN) {
            ws.send(JSON.stringify({ type: 'stream-start' }));
          }

          for await (const chunk of stream) {
            if (ws.readyState !== ws.OPEN) break;
            fullResponse += chunk;
            ws.send(JSON.stringify({ 
              type: 'stream-chunk', 
              payload: { chunk } 
            }));
          }

          // Save complete AI response
          const aiMessage = await storage.createMessage({
            conversationId,
            role: "assistant",
            content: fullResponse,
          });

          if (ws.readyState === ws.OPEN) {
            ws.send(JSON.stringify({ 
              type: 'stream-end', 
              payload: { message: aiMessage } 
            }));
          }

          // Update conversation timestamp
          await storage.updateConversation(conversationId, {
            updatedAt: new Date(),
          });
        }
      } catch (error) {
        console.error('WebSocket error:', error);
        if (ws.readyState === ws.OPEN) {
          ws.send(JSON.stringify({ 
            type: 'error', 
            payload: { message: 'Failed to process request' } 
          }));
        }
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket connection error:', error);
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  return httpServer;
}

function getLanguageFromFilename(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase();
  const languageMap: Record<string, string> = {
    'py': 'python',
    'js': 'javascript',
    'ts': 'typescript',
    'jsx': 'javascript',
    'tsx': 'typescript',
    'java': 'java',
    'cpp': 'cpp',
    'c': 'c',
    'cs': 'csharp',
    'php': 'php',
    'rb': 'ruby',
    'go': 'go',
    'rs': 'rust',
    'swift': 'swift',
    'kt': 'kotlin',
    'dart': 'dart',
    'scala': 'scala',
    'sh': 'bash',
    'sql': 'sql',
    'html': 'html',
    'css': 'css',
    'json': 'json',
    'xml': 'xml',
    'yaml': 'yaml',
    'yml': 'yaml',
  };

  return languageMap[ext || ''] || 'text';
}
