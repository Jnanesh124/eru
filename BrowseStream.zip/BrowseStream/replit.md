# Overview

This is an AI coding assistant application with a ChatGPT-inspired interface, built as a full-stack TypeScript application. The project provides comprehensive programming language support (50+ languages), real-time chat functionality, code execution capabilities, and advanced syntax highlighting. It features a modern React frontend with Express.js backend, designed to offer instant programming help and code assistance.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The client-side is built with **React 18** using TypeScript and modern development practices:

- **UI Framework**: React with Vite for fast development and building
- **Styling**: Tailwind CSS with a comprehensive design system using CSS variables for theming
- **Component Library**: Shadcn/ui components built on Radix UI primitives for accessibility
- **State Management**: TanStack React Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Theme Support**: Light/dark mode with system preference detection
- **Code Highlighting**: Highlight.js with support for 20+ programming languages including JavaScript, Python, Java, C++, Go, Rust, and more

The frontend follows a component-based architecture with clear separation between UI components, business logic hooks, and utility functions. The chat interface supports real-time messaging, code block rendering with syntax highlighting, and responsive design.

## Backend Architecture

The server-side uses **Express.js** with TypeScript in ESM format:

- **Runtime**: Node.js with native ES modules
- **API Design**: RESTful endpoints with WebSocket support for real-time features
- **Request Handling**: Express middleware for JSON parsing, CORS, request logging, and error handling
- **Development**: Hot reloading with Vite integration for seamless full-stack development
- **File Uploads**: Multer middleware for handling multipart form data

The backend implements a clean separation between route handlers, business logic services, and data storage layers.

## Data Storage

The application uses a **PostgreSQL** database with Drizzle ORM:

- **ORM**: Drizzle ORM for type-safe database operations with automatic TypeScript inference
- **Schema Management**: Shared schema definitions between client and server using Zod validation
- **Database Provider**: Configured for Neon Database (PostgreSQL-compatible serverless database)
- **Migration System**: Drizzle Kit for database schema migrations and management

The database schema includes tables for users, conversations, messages, and code executions with proper foreign key relationships and constraints.

## Authentication & Session Management

- **User Management**: Simplified user creation and management (demo-ready, can be extended for production auth)
- **Session Storage**: Connect-pg-simple for PostgreSQL-backed session storage
- **Client Storage**: localStorage for user persistence on the frontend

## External Dependencies

- **AI Integration**: OpenAI API for chat completions with GPT-4o model support, including streaming responses for real-time chat experience
- **Database Hosting**: Neon Database for serverless PostgreSQL hosting
- **Development Tools**: Replit-specific integrations for development environment support
- **Font Services**: Google Fonts integration for Inter and JetBrains Mono typography
- **CDN Resources**: Highlight.js stylesheets from CDN for syntax highlighting themes

The application is designed for easy deployment on Replit with built-in development tooling and can be adapted for other hosting platforms.